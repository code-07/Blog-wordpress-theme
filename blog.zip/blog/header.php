<!DOCTYPE html>
<html <?php language_attributes(); global $portfolio_master; ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">

    <!-- Responsive Meta -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- IE Compatibility Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico"> 

    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php wp_head(); ?>
  </head>
  <body>
    <!-- Header Area Start -->
    <header class="header-section">
      <div class="header-area">
        <nav class="navbar navbar-default">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <div class="logo">
                <?php the_custom_logo();?>
              </div> 
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <div class="main-menu">
                <?php 
                  wp_nav_menu(array(
                    'theme_location' => 'primery_menu',
                    'fallback_cb' => 'portfolio_master_fallback_menu',
                    'container' => '',
                    'menu_class' => 'nav navbar-nav navbar-menu navbar-right',

                  )); 
                ?> 
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!--/.Header Area End -->