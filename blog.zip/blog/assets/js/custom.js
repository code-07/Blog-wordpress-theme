$('#stickySocial').find('#stickyBtn').each(function(){
  var $el = $(this);
  var ssCount = $el.data("count");
  var ssClass = $el.attr("class").split(' ')[0];
  $('.'+ssClass+' .count').html(ssCount);
});

/*$('#stickySocial').find('#stickyBtn').each(function(){
  var $e = $(this),
      shareCount = 0,
      newShareCount = $e.data().count;
  
  $({shareCount:shareCount}).animate({shareCount:newShareCount}, {
    duration: 2500,
    easing:'swing', // can be anything
    step: function() {
            $('.count').text(Math.ceil(this.shareCount));
          }
  }); 
});

$({shareCount: 0}).animate({shareCount: 100}, {
  duration: 2500,
  easing:'swing', // can be anything
  step: function() { // called on every step
    // Update the element's text with rounded-up value:
    $('.tweet .count').text(Math.ceil(this.shareCount));
  }
});
$({shareCount: 0}).animate({shareCount: 100}, {
  duration: 2500,
  easing:'swing', // can be anything
  step: function() { // called on every step
    // Update the element's text with rounded-up value:
    $('.pinIt .count').text(Math.ceil(this.shareCount));
  }
});
$({shareCount: 0}).animate({shareCount: 100}, {
  duration: 2500,
  easing:'swing', // can be anything
  step: function() { // called on every step
    // Update the element's text with rounded-up value:
    $('.comment .count').text(Math.ceil(this.shareCount));
  }
});
*/