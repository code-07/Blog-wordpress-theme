<?php get_header(); ?>

    <!-- Breadcumb Area Start -->
    <section class="bredcumb-section">
      <div class="breadcrumb">
        <div class="container">
          <?php the_breadcrumb(); ?>
        </div>
      </div>
    </section>
    <!--/.Breadcumb Area End -->

    <!-- Blog Area Start -->
    <section class="blog-section">
      <div class="container">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-9 article-area">
            <!-- Content Area Start-->
                  <?php
                    if (have_posts()){
                      while (have_posts() ){
                        the_post();
                    ?>
                      <article>
                        <div class="post-content">
                          <div class="post-title">
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                          </div>
                          <div class="post-meta">
                            <h6>Posted by 
                              <span><a href="<?php the_permalink(); ?>"><?php the_author(); ?></a></span> on <?php echo get_the_date(); ?>  
                              <span><a href="<?php the_permalink(); ?>">&nbsp;<?php comments_number(); ?></a></span>
                            </h6>
                          </div>
                          <div class="post-thumbnail">
                            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                          </div>
                          <div class="post-article">
                            <p><?php the_excerpt(); ?></p>
                          </div> 
                        </div>
                      </article>
                    <?php }
                    }else {
                      echo "no post";
                    }
                      wp_reset_postdata();
                    ?>
              <div class="pagination-area">
                    <?php the_posts_pagination(array(
                        'mid_size' => 2,
                        'prev_text' => '<i class="fa fa-angle-left"></i>',
                        'next_text' => '<i class="fa fa-angle-right"></i>',
                        'screen_reader_text' => ' ',
                      ));
                    ?>
              </div>   
            </div>
            <?php get_sidebar(); ?>
          </div> <!--/.Blog Row End -->
        </div> <!--/.Blog Col-12 End -->  
      </div> <!--/.Blog Container End -->
    </section> <!--/.Blog Section End -->
    <!--/.Blog Area End -->

<?php get_footer(); ?>