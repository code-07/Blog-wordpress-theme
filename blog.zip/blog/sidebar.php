            <div class="col-md-3 aside-area">
            <!-- Sidebar Widget Area Start-->
              <aside class="sidebar-area">
                <div class="widget-area">
                  <?php dynamic_sidebar('sidebar');?> 
                </div>
              </aside> 
            </div>