<?php get_header(); ?>

    <!-- Breadcumb Area Start -->
    <section class="bredcumb-section">
      <div class="breadcrumb">
        <div class="container">
          <?php the_breadcrumb(); ?>
        </div>
      </div>
    </section>
    <!--/.Breadcumb Area End -->

    <!-- Blog Area Start -->
    <section class="blog-section">
      <div class="container">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-9 article-area">
            <!-- Content Area Start-->
                  <?php
                    if (have_posts()){
                      while (have_posts() ){
                        the_post();
                    ?>
                      <article>
                        <div class="post-content">
                          <div class="post-title">
                            <h2><a href="#"><?php the_title(); ?></a></h2>
                          </div>
                          <div class="post-thumbnail">
                            <a href="#"><?php the_post_thumbnail(); ?></a>
                          </div>
                          <div class="post-article">
                            <p><?php the_content(); ?></p>
                          </div> 
                        </div>
                      </article>
                    <?php }
                    }else {
                      echo "no post";
                    }
                      wp_reset_postdata();
                    ?>
              <div class="releted-post-area">
                <h3 class="text-center">Related Post</h3>
                <div class="releted-post">
                  <div class="post-image">
                    <a href=""><img src="<?php echo get_template_directory_uri();?>/assets/img/img1.jpg" alt=""></a>
                  </div>
                  <div class="post-title">
                    <a href=""><h4>Lorem ipsum dolor sit amet.</h4></a>
                  </div>
                </div>
                <div class="releted-post">
                  <div class="post-image">
                    <a href=""><img src="<?php echo get_template_directory_uri();?>/assets/img/img1.jpg" alt=""></a>
                  </div>
                  <div class="post-title">
                    <a href=""><h4>Lorem ipsum dolor sit amet.</h4></a>
                  </div>
                </div>
                <div class="releted-post">
                  <div class="post-image">
                    <a href=""><img src="<?php echo get_template_directory_uri();?>/assets/img/img1.jpg" alt=""></a>
                  </div>
                  <div class="post-title">
                    <a href=""><h4>Lorem ipsum dolor sit amet.</h4></a>
                  </div>
                </div>
              </div>
              <div class="comments-area">
                <?php comments_template();?>
              </div> 
              <div class="post-navigation">
                <div class="prev">
                  <h3><?php previous_post_link(); ?></h3>
                </div>
                <div class="next">
                  <h3><?php next_post_link(); ?></h3>
                </div>
              </div>  
            </div>
            <?php get_sidebar(); ?>          
          </div> <!--/.Blog Row End -->
        </div> <!--/.Blog Col-12 End -->  
      </div> <!--/.Blog Container End -->
    </section> <!--/.Blog Section End -->
    <!--/.Blog Area End -->

<?php get_footer(); ?>