<?php get_header(); ?>

    <!-- Slider Area Start -->
    <section class="slider-section">
      <div class="container">
        <div class="header-slider">
           <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

            
            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
              <?php 
                $blog_post = null;
                $blog_post = new WP_Query(array(
                  'post_type'=>'post',
                  'posts_per_page'=>3

                ));
                if ($blog_post->have_posts() ){
                  $x=0;
                  while ($blog_post->have_posts() ){
                    $x++;
                    $blog_post->the_post();
                    ?>

                    <div class="item <?php if ($x==1){ echo 'active';} ?>">
                      <?php the_post_thumbnail() ?> 
                      <div class="carousel-caption">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                      </div>        
                    </div>   

                <?php }
                  }else{
                  echo "No Post";
                }
                wp_reset_postdata();
              ?>

            <ol class="carousel-indicators">
              <?php 
                for($i=0; $i<$x; $i++){ ?>
                <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i;?>" class="<?php if ($i==0){ echo 'active';} ?>"></li>
              <?php }
              ?>

            </ol>

            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>

          </div>
        </div>
      </div>
    </section>
    <!--/.Slider Area End -->

    <!-- Feature Area Start -->
    <section class="feature-section common-feature">
      <div class="container">
        <div class="col-md-12 ftr-pd">
          <div class="heading">
            <h2>Features</h2>
          </div>
          <div class="row">
              <?php
                $blog_post = null;
                $blog_post = new WP_Query(array(
                  'post_type'=>'post',
                  'posts_per_page'=>2,
                  'meta_key' => 'meta-checkbox',
                  'meta_value' => 'yes'


                ));
                if ($blog_post->have_posts() ){
                  while ($blog_post->have_posts() ){
                    $blog_post->the_post();
                    ?>
                      <div class="col-md-6">
                        <article>
                          <div class="post-content">
                            <div class="post-thumbnail">
                              <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?>
                              </a>
                            </div>
                            <div class="post-title">
                              <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            </div>
                            <div class="post-article">
                              <p><?php the_excerpt(); ?></p>
                            </div> 
                          </div>
                        </article>
                      </div>

              <?php }
                }else{
                echo "No Post";
              }
              wp_reset_postdata();
              ?>
        </div>

      </div> <!--/.feature Container End -->
    </section> <!--/.feature Section End -->
    <!--/.Feature Area End -->

    <!-- Recent Area Start -->
    <section class="recent-section common-feature">
      <div class="container">
        <div class="col-md-12 ftr-pd">
          <div class="heading">
            <h2>Recent</h2>
          </div>
          <div class="row">
              <?php
                $blog_post = null;
                $blog_post = new WP_Query(array(
                  'post_type'=>'post',
                  'posts_per_page'=>3,

                ));
                if ($blog_post->have_posts() ){
                  while ($blog_post->have_posts() ){
                    $blog_post->the_post();
                    ?>
            <div class="col-md-4">
              <article>
                <div class="post-content">
                  <div class="post-thumbnail">
                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                  </div>
                  <div class="post-title">
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                  </div>
                  <div class="post-article">
                    <p><?php the_excerpt(); ?></p>
                  </div> 
                </div>
              </article>
            </div>
              <?php }
                }else{
                echo "No Post";
              }
              wp_reset_postdata();
              ?>
          </div>
        </div>
      </div> <!--/.feature Container End -->
    </section> <!--/.Recent Section End -->
    <!--/.Recent Area End -->

    <!-- Popular Area Start -->
    <section class="popular-section common-feature">
      <div class="container">
        <div class="col-md-12 ftr-pd">
          <div class="heading">
            <h2>Popular</h2>
          </div>
          <div class="row">
            <?php
                $blog_post = null;
                $blog_post = new WP_Query(array(
                  'post_type'=>'post',
                  'posts_per_page'=>2,
                  'meta_key' => 'wpb_post_views_count',
                  'orderby' => 'meta_value_num',
                  'order' => 'DESC'

                ));
                if ($blog_post->have_posts() ){
                  while ($blog_post->have_posts() ){
                    $blog_post->the_post();
                    ?>
                  <div class="col-md-6">
                    <article>
                      <div class="post-content">
                        <div class="post-thumbnail">
                          <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                        </div>
                        <div class="post-title">
                          <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        </div>
                        <div class="post-article">
                          <p><?php the_excerpt(); ?></p>
                        </div> 
                      </div>
                    </article>
                  </div>
              <?php }
                }else{
                echo "No Post";
              }
              wp_reset_postdata();
              ?>
          </div>
        </div>
      </div> <!--/.feature Container End -->
    </section> <!--/.Popular Section End -->
    <!--/.Popular Area End -->

    <?php get_footer(); ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php echo get_template_directory_uri();?>/assets/js/jquery.min.js"><\/script>')</script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo get_template_directory_uri();?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/assets/js/custom.js"></script>
  </body>
</html>