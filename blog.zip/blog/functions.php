<?php

function portfolio_master_theme_support (){
	add_theme_support('title-tag');
	register_nav_menus(array(
		'primery_menu' => 'Primery Menu',
		'footer_menu' => 'Footer Menu',
	));
	add_theme_support('post-thumbnails');
	add_theme_support( 'custom-logo' );
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );
		add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'audio',
	) );


}
add_action('after_setup_theme','portfolio_master_theme_support');

function portfolio_master_css_js (){
  wp_enqueue_style('bootstrap',get_template_directory_uri().'/assets/css/bootstrap.min.css', null, 'v1.0', 'all');
  wp_enqueue_style('font-awesome',get_template_directory_uri().'/assets/css/font-awesome.min.css', null, 'v1.0', 'all');
  wp_enqueue_style('theme-style',get_template_directory_uri().'/assets/css/style.css', null, 'v1.0', 'all');
  wp_enqueue_style('responsive',get_template_directory_uri().'/assets/css/responsive.css', null, 'v1.0', 'all');
  wp_enqueue_style('main-style',get_stylesheet_uri());



  wp_enqueue_script('jquery');
  wp_enqueue_script('bootstrap',get_template_directory_uri().'/assets/js/bootstrap.min.js', 'jquery', null, true); 
  wp_enqueue_script('hans',get_template_directory_uri().'/assets/js/custom.js', 'jquery', null, true);
}
add_action('wp_enqueue_scripts','portfolio_master_css_js');

function portfolio_master_fallback_menu (){ ?>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="index.html">Home</a></li>
      <li><a href="about.html">About</a></li>
      <li><a href="blog.html">Blog</a></li>
      <li><a href="#">Policy</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul>
<?php }


function portfolio_master_fallback_menu2 (){ ?>
	<ul>
                      <li><a href="#"><i class=" fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class=" fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class=" fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class=" fa fa-google-plus"></i></a></li>
                    </ul>
<?php }


function our_widgets(){
	register_sidebar(array(
		'name' 				=> 'Sidebar',
		'description'     	=> 'Add your widget',
		'id'				=> 'sidebar',
		'before_widget'		=> '<div class="widget-area">',
		'before_title'		=> '<div class="widget-title"><h3>',
		'after_title'		=> '</h3></div><div class="widget-container">',
		'after_widget'		=> '</div></div>'
	));
	register_sidebar(array(
		'name' 				=> 'Footer-1',
		'description'     	=> 'Add your widget',
		'id'				=> 'footer-1',

	));

	register_sidebar(array(
		'name' 				=> 'Footer-2',
		'description'     	=> 'Add your widget',
		'id'				=> 'footer-2',

	));

}
add_action('widgets_init','our_widgets');


function the_breadcrumb() {
	if (!is_home()) {
		echo '<a href="';
		echo get_option('home');
		echo '">';
		bloginfo('name');
		echo "</a> / ";
		if (is_category() || is_single()) {
			the_category('title_li=');
			if (is_single()) {
				echo " / ";
				the_title();
			}
		} elseif (is_page()) {
			echo the_title();
		}
	}
}

// functions for share button 


function crunchify_social_sharing_buttons($content) {
	global $post;
	if(is_singular() || is_home()){
	
		// Get current page URL 
		$crunchifyURL = urlencode(get_permalink());
 
		// Get current page title
		$crunchifyTitle = str_replace( ' ', '%20', get_the_title());
		
		// Get Post Thumbnail for pinterest
		$crunchifyThumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
 
		// Construct sharing URL without using any script
		$twitterURL = 'https://twitter.com/intent/tweet?text='.$crunchifyTitle.'&amp;url='.$crunchifyURL.'&amp;via=Crunchify';
		$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$crunchifyURL;
		$googleURL = 'https://plus.google.com/share?url='.$crunchifyURL;
		$bufferURL = 'https://bufferapp.com/add?url='.$crunchifyURL.'&amp;text='.$crunchifyTitle;
		$whatsappURL = 'whatsapp://send?text='.$crunchifyTitle . ' ' . $crunchifyURL;
		$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$crunchifyURL.'&amp;title='.$crunchifyTitle;
 
		// Based on popular demand added Pinterest too
		$pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$crunchifyURL.'&amp;media='.$crunchifyThumbnail[0].'&amp;description='.$crunchifyTitle;
 
		// Add sharing button at the end of page/page content
		$content .= '<!-- Crunchify.com social sharing. Get your copy here: http://crunchify.me/1VIxAsz -->';
		$content .= '<div class="crunchify-social">';
		$content .= '<h5>SHARE ON</h5> <a class="crunchify-link crunchify-twitter" href="'. $twitterURL .'" target="_blank">Twitter</a>';
		$content .= '<a class="crunchify-link crunchify-facebook" href="'.$facebookURL.'" target="_blank">Facebook</a>';
		$content .= '<a class="crunchify-link crunchify-whatsapp" href="'.$whatsappURL.'" target="_blank">WhatsApp</a>';
		$content .= '<a class="crunchify-link crunchify-googleplus" href="'.$googleURL.'" target="_blank">Google+</a>';
		$content .= '<a class="crunchify-link crunchify-buffer" href="'.$bufferURL.'" target="_blank">Buffer</a>';
		$content .= '<a class="crunchify-link crunchify-linkedin" href="'.$linkedInURL.'" target="_blank">LinkedIn</a>';
		$content .= '<a class="crunchify-link crunchify-pinterest" href="'.$pinterestURL.'" data-pin-custom="true" target="_blank">Pin It</a>';
		$content .= '</div>';
		
		return $content;
	}else{
		// if not a post/page then don't include sharing button
		return $content;
	}
};
add_filter( 'the_content', 'crunchify_social_sharing_buttons');

// functions for feature post 

 function sm_custom_meta() {
    add_meta_box( 'sm_meta', __( 'Featured Posts', 'sm-textdomain' ), 'sm_meta_callback', 'post' );
}
function sm_meta_callback( $post ) {
    $featured = get_post_meta( $post->ID );
    ?>
 
	<p>
    <div class="sm-row-content">
        <label for="meta-checkbox">
            <input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes" <?php if ( isset ( $featured['meta-checkbox'] ) ) checked( $featured['meta-checkbox'][0], 'yes' ); ?> />
            <?php _e( 'Featured this post', 'sm-textdomain' )?>
        </label>
        
    </div>
</p>
 
    <?php
}
add_action( 'add_meta_boxes', 'sm_custom_meta' );


function sm_meta_save( $post_id ) {
 
    // Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'sm_nonce' ] ) && wp_verify_nonce( $_POST[ 'sm_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
 
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
 
 // Checks for input and saves
if( isset( $_POST[ 'meta-checkbox' ] ) ) {
    update_post_meta( $post_id, 'meta-checkbox', 'yes' );
} else {
    update_post_meta( $post_id, 'meta-checkbox', '' );
}
 
}
add_action( 'save_post', 'sm_meta_save' );

// functions for excerpt post
function custom_excerpt_length( $length ) {
	return 40;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

// functions for popular post
function wpb_get_post_views($postID){
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    return $count.' Views';
}

