    <!-- Footer Area Start -->
    <section class="footer-section">
      <div class="footer-area">
        <div class="container">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-4">
                <div class="footer-1">
                  <div class="footer-logo">

                    <!-- <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo-footer@2x.png" alt=""></a> -->
                    <a href="#"><?php dynamic_sidebar('footer-1');?></a>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="footer-2">
                  <div class="footer-menu">
                      <?php dynamic_sidebar('footer-2');?>
<!--                     <ul>
                      <li><a href="#">Home</a></li>
                      <li><a href="#">About</a></li>
                      <li><a href="#">Blog</a></li>
                      <li><a href="#">Policy</a></li>
                      <li><a href="#">Contact</a></li>
                    </ul> -->
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="footer-3">
                  <div class="footer-social">
                    <?php 
                      wp_nav_menu(array(
                        'theme_location' => 'footer_menu',
                        'fallback_cb' => 'portfolio_master_fallback_menu2',
                        'container' => '',
                        'menu_class' => '',

                      )); 
                    ?>
<!--                     <ul>
                      <li><a href="#"><i class=" fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class=" fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class=" fa fa-linkedin"></i></a></li>
                      <li><a href="#"><i class=" fa fa-google-plus"></i></a></li>
                    </ul> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-copy text-center">
        <p>Copyright @ All reserved by Abu Taher</p>
      </div>
    </section>
    <!-- Footer Area End -->
    <?php wp_footer(); ?>
  </body>
</html>